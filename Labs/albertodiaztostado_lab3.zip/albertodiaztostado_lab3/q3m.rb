#!/usr/bin/ruby
#
# Alberto Diaz
# COEN 164L
# Lab 3
# Module Gym
#
module Dojo
  class Push
    def up
      30
    end
  end
end

module Gym
  class Push
    def up
      40
    end
  end
end