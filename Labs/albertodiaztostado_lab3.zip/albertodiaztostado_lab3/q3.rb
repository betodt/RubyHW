#!/usr/bin/ruby
#
# Alberto Diaz
# COEN 164L
# Lab 3
# Question 3
#
require_relative "q3m"

gym_push = Gym::Push.new
p gym_push.up 

dojo_push = Dojo::Push.new
p dojo_push.up 